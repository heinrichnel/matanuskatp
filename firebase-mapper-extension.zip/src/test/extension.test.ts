import * as assert from 'assert';
import { scanForFirebaseCalls } from '../analyzers/firebaseScanner';

suite('Firebase Usage Test', () => {
  test('Detects Firebase usage', () => {
    const content = `addDoc(collection(db, "trips"), { id: "123" });`;
    const found = scanForFirebaseCalls(content);
    assert.deepStrictEqual(found, ['addDoc', 'collection']);
  });
});