import * as vscode from 'vscode';
import { scanForFirebaseCalls } from './analyzers/firebaseScanner';
import { validateBindings } from './commands/validateBindings';
import { FirebaseTreeProvider } from './ui/FirebasePanel';

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument(doc => {
      const result = scanForFirebaseCalls(doc.getText());
      if (result.length) vscode.window.showInformationMessage(`🔥 Firebase Used: ${result.join(', ')}`);
    }),

    vscode.commands.registerCommand('extension.validateBindings', validateBindings),
    vscode.window.registerTreeDataProvider('firebaseIntegrationMap', new FirebaseTreeProvider())
  );
}