import * as vscode from 'vscode';

export class FirebaseTreeProvider implements vscode.TreeDataProvider<vscode.TreeItem> {
  getChildren(): vscode.ProviderResult<vscode.TreeItem[]> {
    return [
      new vscode.TreeItem('TripForm.tsx → addDoc → trips'),
      new vscode.TreeItem('DieselImport.tsx → setDoc → diesel')
    ];
  }

  getTreeItem(element: vscode.TreeItem): vscode.TreeItem {
    return element;
  }
}