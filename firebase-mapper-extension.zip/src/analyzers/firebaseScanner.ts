export function scanForFirebaseCalls(fileContent: string): string[] {
  const usages = [];
  if (fileContent.includes('addDoc')) usages.push('addDoc');
  if (fileContent.includes('onSnapshot')) usages.push('onSnapshot');
  if (fileContent.includes('collection(')) usages.push('collection');
  if (fileContent.includes('updateDoc')) usages.push('updateDoc');
  return usages;
}