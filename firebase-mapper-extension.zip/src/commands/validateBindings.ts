import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import { scanForFirebaseCalls } from '../analyzers/firebaseScanner';

export function validateBindings() {
  const folders = vscode.workspace.workspaceFolders;
  if (!folders) return;

  const srcPath = path.join(folders[0].uri.fsPath, 'src');
  const report: Record<string, string[]> = {};

  function scanDir(dir: string) {
    fs.readdirSync(dir).forEach(file => {
      const full = path.join(dir, file);
      if (fs.statSync(full).isDirectory()) return scanDir(full);
      if (!file.endsWith('.ts') && !file.endsWith('.tsx')) return;

      const content = fs.readFileSync(full, 'utf8');
      const result = scanForFirebaseCalls(content);
      if (result.length) report[full] = result;
    });
  }

  scanDir(srcPath);
  fs.writeFileSync(path.join(folders[0].uri.fsPath, 'integration-report.json'), JSON.stringify(report, null, 2));
  vscode.window.showInformationMessage('✅ Firebase validation complete.');
}