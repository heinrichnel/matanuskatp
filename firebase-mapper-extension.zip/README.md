# Firebase Mapper VS Code Extension

Maps frontend usage of Firebase (addDoc, onSnapshot, etc.) and displays integration via TreeView.

## Commands
- Validate Firebase Bindings
- View Firebase Integration Map
